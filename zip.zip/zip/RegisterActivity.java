package com.example.projektmunka;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

public class RegisterActivity extends AppCompatActivity {

    private EditText emailEditText;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private ImageView eyeIcon;
    private TextView regSuccessMessage; // Szöveg a sikeres regisztrációhoz
    private boolean isPasswordVisible = false;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Az elemek azonosítása a layoutból
        emailEditText = findViewById(R.id.textEmail);
        usernameEditText = findViewById(R.id.textUsername);
        passwordEditText = findViewById(R.id.textPassword);
        eyeIcon = findViewById(R.id.eye_icon);
        regSuccessMessage = findViewById(R.id.registrationSuccessMessage);
        regSuccessMessage.setVisibility(View.GONE); // Alapból rejtett

        mAuth = FirebaseAuth.getInstance();

        // Jelszó láthatóság váltása az eye ikonra kattintáskor
        eyeIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isPasswordVisible) {
                    passwordEditText.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    eyeIcon.setImageResource(R.drawable.ic_eye_closed);
                    isPasswordVisible = false;
                } else {
                    passwordEditText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    eyeIcon.setImageResource(R.drawable.ic_eye_open);
                    isPasswordVisible = true;
                }
                // Megtartjuk a kurzor pozícióját
                passwordEditText.setSelection(passwordEditText.getText().length());
            }
        });
    }

    public void Register(View view) {
        String email = emailEditText.getText().toString().trim();
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (email.isEmpty() || username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Email, felhasználónév és jelszó megadása kötelező!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Firebase felhasználó létrehozása e-mail és jelszó alapján
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser firebaseUser = mAuth.getCurrentUser();
                        if (firebaseUser != null) {
                            // Frissítjük a felhasználói profilt a displayName (felhasználónév) beállításával
                            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                    .setDisplayName(username)
                                    .build();
                            firebaseUser.updateProfile(profileUpdates)
                                    .addOnCompleteListener(task1 -> {
                                        if (task1.isSuccessful()) {
                                            // Regisztráció sikeres – megjelenítjük a villogó zöld üzenetet
                                            regSuccessMessage.setVisibility(View.VISIBLE);
                                            AlphaAnimation blinkAnimation = new AlphaAnimation(0.0f, 1.0f);
                                            blinkAnimation.setDuration(500); // 500ms ciklusok
                                            blinkAnimation.setRepeatMode(AlphaAnimation.REVERSE);
                                            blinkAnimation.setRepeatCount(5); // 5 ismétlés
                                            regSuccessMessage.startAnimation(blinkAnimation);

                                            // 2 másodperc elteltével navigálunk a LoginActivity-re
                                            new Handler().postDelayed(() -> {
                                                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                                                startActivity(intent);
                                                finish();
                                            }, 2000);
                                        } else {
                                            String error = task1.getException() != null
                                                    ? task1.getException().getMessage()
                                                    : "Hiba történt a profilfrissítéskor!";
                                            Toast.makeText(RegisterActivity.this, "Hiba: " + error, Toast.LENGTH_LONG).show();
                                        }
                                    });
                        }
                    } else {
                        String error = task.getException() != null
                                ? task.getException().getMessage()
                                : "Hiba történt!";
                        Toast.makeText(RegisterActivity.this, "Sikertelen regisztráció: " + error, Toast.LENGTH_LONG).show();
                    }
                });
    }

    public void goToLogin(View view) {
        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
        startActivity(intent);
    }
}
