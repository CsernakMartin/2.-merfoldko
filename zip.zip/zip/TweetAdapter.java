package com.example.projektmunka;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class TweetAdapter extends ArrayAdapter<Tweet> {
    private Context mContext;
    private boolean canDelete; // Flag, amely megmondja, hogy törölni lehet-e

    public TweetAdapter(@NonNull Context context, @NonNull List<Tweet> objects, boolean canDelete) {
        super(context, 0, objects);
        mContext = context;
        this.canDelete = canDelete;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if (listItem == null) {
            listItem = LayoutInflater.from(mContext).inflate(R.layout.tweet_item, parent, false);
        }

        Tweet currentTweet = getItem(position);

        // Elemek lekérése a layoutból
        TextView tweetTextView = listItem.findViewById(R.id.textViewTweet);
        TextView usernameView = listItem.findViewById(R.id.textViewUsername);
        ImageView likeIcon = listItem.findViewById(R.id.imageViewLike);
        TextView likeCountView = listItem.findViewById(R.id.textViewLikeCount);
        ImageView deleteIcon = listItem.findViewById(R.id.imageViewDelete);
        ImageView bookmarkIcon = listItem.findViewById(R.id.imageViewBookmark);
        // Új elem: kép megjelenítésére szolgáló ImageView
        ImageView tweetPhoto = listItem.findViewById(R.id.imageViewTweetPhoto);

        if (currentTweet != null) {
            tweetTextView.setText(currentTweet.getText());
            usernameView.setText(currentTweet.getUsername());
            likeCountView.setText(String.valueOf(currentTweet.getLikeCount()));

            // Kép betöltése, ha az imageUrl értéke nem üres
            if (currentTweet.getImageUrl() != null && !currentTweet.getImageUrl().isEmpty()) {
                tweetPhoto.setVisibility(View.VISIBLE);
                Glide.with(mContext)
                        .load(currentTweet.getImageUrl())
                        .into(tweetPhoto);
            } else {
                tweetPhoto.setVisibility(View.GONE);
            }
        }

        // Like toggle funkció
        likeIcon.setOnClickListener(v -> {
            if (currentTweet == null) return;
            String currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            DocumentReference tweetRef = FirebaseFirestore.getInstance()
                    .collection("user_tweets")
                    .document(currentTweet.getUsername())
                    .collection("tweets")
                    .document(currentTweet.getId());

            FirebaseFirestore.getInstance().runTransaction(transaction -> {
                DocumentSnapshot snapshot = transaction.get(tweetRef);
                List<String> likedBy = (List<String>) snapshot.get("likedBy");
                if (likedBy == null) {
                    likedBy = new ArrayList<>();
                }
                boolean isLiked = likedBy.contains(currentUserId);
                if (isLiked) {
                    transaction.update(tweetRef, "likedBy", FieldValue.arrayRemove(currentUserId));
                    transaction.update(tweetRef, "likeCount", FieldValue.increment(-1));
                } else {
                    transaction.update(tweetRef, "likedBy", FieldValue.arrayUnion(currentUserId));
                    transaction.update(tweetRef, "likeCount", FieldValue.increment(1));
                }
                return isLiked;
            }).addOnSuccessListener(result -> {
                if (result instanceof Boolean && ((Boolean) result)) {
                    currentTweet.setLikeCount(currentTweet.getLikeCount() - 1);
                    Toast.makeText(mContext, "Like removed", Toast.LENGTH_SHORT).show();
                } else {
                    currentTweet.setLikeCount(currentTweet.getLikeCount() + 1);
                    Toast.makeText(mContext, "Liked!", Toast.LENGTH_SHORT).show();
                }
                likeCountView.setText(String.valueOf(currentTweet.getLikeCount()));
            }).addOnFailureListener(e -> {
                Toast.makeText(mContext, "Hiba a like mentésekor: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        });

        // Bookmark toggle funkció
        bookmarkIcon.setOnClickListener(v -> {
            if (currentTweet == null) return;
            String currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            DocumentReference tweetRef = FirebaseFirestore.getInstance()
                    .collection("user_tweets")
                    .document(currentTweet.getUsername())
                    .collection("tweets")
                    .document(currentTweet.getId());

            FirebaseFirestore.getInstance().runTransaction(transaction -> {
                DocumentSnapshot snapshot = transaction.get(tweetRef);
                List<String> bookmarkedBy = (List<String>) snapshot.get("bookmarkedBy");
                if (bookmarkedBy == null) {
                    bookmarkedBy = new ArrayList<>();
                }
                boolean isBookmarked = bookmarkedBy.contains(currentUserId);
                if (isBookmarked) {
                    transaction.update(tweetRef, "bookmarkedBy", FieldValue.arrayRemove(currentUserId));
                } else {
                    transaction.update(tweetRef, "bookmarkedBy", FieldValue.arrayUnion(currentUserId));
                }
                return isBookmarked;
            }).addOnSuccessListener(result -> {
                if (result instanceof Boolean && ((Boolean) result)) {
                    currentTweet.getBookmarkedBy().remove(FirebaseAuth.getInstance().getCurrentUser().getUid());
                    bookmarkIcon.setImageResource(R.drawable.bookmark_outline);
                    Toast.makeText(mContext, "Bookmark removed", Toast.LENGTH_SHORT).show();
                } else {
                    currentTweet.getBookmarkedBy().add(FirebaseAuth.getInstance().getCurrentUser().getUid());
                    bookmarkIcon.setImageResource(R.drawable.bookmark);
                    Toast.makeText(mContext, "Bookmarked", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(e -> {
                Toast.makeText(mContext, "Hiba a bookmark toggle műveletnél: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        });

        // Bookmark ikon kezdeti állapotának beállítása
        String currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        if (currentTweet.getBookmarkedBy() != null && currentTweet.getBookmarkedBy().contains(currentUserId)) {
            bookmarkIcon.setImageResource(R.drawable.bookmark);
        } else {
            bookmarkIcon.setImageResource(R.drawable.bookmark_outline);
        }

        // Törlés funkció, ha engedélyezett
        if (canDelete) {
            deleteIcon.setVisibility(View.VISIBLE);
            deleteIcon.setOnClickListener(v -> {
                if (currentTweet == null) return;
                FirebaseFirestore.getInstance()
                        .collection("user_tweets")
                        .document(currentTweet.getUsername())
                        .collection("tweets")
                        .document(currentTweet.getId())
                        .delete()
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(mContext, "Tweet törölve", Toast.LENGTH_SHORT).show();
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(mContext, "Hiba: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        });
            });
        } else {
            deleteIcon.setVisibility(View.GONE);
        }

        return listItem;
    }
}
