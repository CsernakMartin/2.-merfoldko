package com.example.projektmunka;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class BookmarksActivity extends AppCompatActivity {

    private ListView listViewBookmarks;
    private ArrayList<Tweet> bookmarkList;
    private TweetAdapter tweetAdapter;
    private FirebaseFirestore db;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmarks);

        // Beállítjuk a toolbar-t
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if(getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Könyvjelzők");
        }

        listViewBookmarks = findViewById(R.id.listViewBookmarks);
        bookmarkList = new ArrayList<>();
        tweetAdapter = new TweetAdapter(this, bookmarkList, false);
        listViewBookmarks.setAdapter(tweetAdapter);

        db = FirebaseFirestore.getInstance();
        currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if(currentUser == null){
            Toast.makeText(this, "Kérlek jelentkezz be!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            loadBookmarks();
        }
    }

    private void loadBookmarks(){
        // Gyűjtjük össze a tweeteket, ahol a "bookmarkedBy" tömb tartalmazza az aktuális user UID-jét.
        db.collectionGroup("tweets")
                .whereArrayContains("bookmarkedBy", currentUser.getUid())
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((QuerySnapshot snapshots, FirebaseFirestoreException error) -> {
                    if(error != null){
                        Toast.makeText(BookmarksActivity.this, "Hiba a könyvjelzők betöltésekor: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        return;
                    }
                    bookmarkList.clear();
                    if(snapshots != null){
                        for(DocumentSnapshot doc : snapshots.getDocuments()){
                            String tweetText = doc.getString("text");
                            String tweetUsername = doc.getString("username");
                            Long likeCount = doc.getLong("likeCount");
                            if(likeCount == null) {
                                likeCount = 0L;
                            }
                            // Olvassuk ki a "bookmarkedBy" tömböt is
                            List<String> bookmarkedBy = (List<String>) doc.get("bookmarkedBy");
                            if(bookmarkedBy == null) {
                                bookmarkedBy = new ArrayList<>();
                            }
                            if(tweetText != null && tweetUsername != null){
                                // Használjuk az öt paraméteres konstruktort: id, text, username, likeCount, bookmarkedBy.
                                bookmarkList.add(new Tweet(doc.getId(), tweetText, tweetUsername, likeCount, bookmarkedBy));
                            }
                        }
                        tweetAdapter.notifyDataSetChanged();
                    }
                });
    }

    // Visszalépő gomb működésének megjelenítése
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
