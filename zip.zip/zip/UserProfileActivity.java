package com.example.projektmunka;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class UserProfileActivity extends AppCompatActivity {

    private TextView textViewWelcome;
    private DrawerLayout drawerLayout;
    private EditText editTextTweet;
    private Button buttonTweet, buttonSelectImage;
    private ListView listViewTweets;
    private ArrayList<Tweet> tweetList;
    private TweetAdapter tweetAdapter;
    private FirebaseFirestore db;

    // Új mezők a kép feltöltéséhez
    private ImageView imageViewPreview;
    private Uri selectedImageUri = null;
    private static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userprofile);

        textViewWelcome = findViewById(R.id.textViewWelcome);

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        String displayName;
        if (currentUser != null && currentUser.getDisplayName() != null && !currentUser.getDisplayName().isEmpty()) {
            displayName = currentUser.getDisplayName();
        } else if (currentUser != null && currentUser.getEmail() != null) {
            displayName = currentUser.getEmail();
        } else {
            displayName = "Ismeretlen";
        }
        textViewWelcome.setText("Üdv, " + displayName + "!");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if(getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);

        LayoutInflater inflater = LayoutInflater.from(this);
        View customView = inflater.inflate(R.layout.toolbar_image, null);
        Toolbar.LayoutParams layoutParams = new Toolbar.LayoutParams(
                Toolbar.LayoutParams.WRAP_CONTENT,
                Toolbar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        toolbar.addView(customView, layoutParams);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        toggle.getDrawerArrowDrawable().setColor(getResources().getColor(android.R.color.holo_blue_light));
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.inflateMenu(R.menu.userprofile_menu);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if(id == R.id.nav_home) {
                    startActivity(new Intent(UserProfileActivity.this, MainActivity.class));
                } else if(id == R.id.nav_settings) {
                    startActivity(new Intent(UserProfileActivity.this, SettingsActivity.class));
                } else if(id == R.id.nav_profile) {
                    // Már ezen az oldalon vagyunk.
                } else if (id == R.id.nav_bookmark){
                    startActivity(new Intent(UserProfileActivity.this, BookmarksActivity.class));
                }
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        editTextTweet = findViewById(R.id.editTextTweet);
        buttonTweet = findViewById(R.id.buttonTweet);
        buttonSelectImage = findViewById(R.id.buttonSelectImage);  // Új gomb a képválasztáshoz
        listViewTweets = findViewById(R.id.listViewTweets);
        imageViewPreview = findViewById(R.id.imageViewPreview);      // Előnézeti ImageView

        tweetList = new ArrayList<>();
        tweetAdapter = new TweetAdapter(this, tweetList, true);
        listViewTweets.setAdapter(tweetAdapter);
        db = FirebaseFirestore.getInstance();

        // Tweetek betöltése a Firestore-ból (csak az aktuális felhasználó tweetjei)
        if (currentUser != null) {
            String usernameKey;
            if (currentUser.getDisplayName() != null && !currentUser.getDisplayName().isEmpty()) {
                usernameKey = currentUser.getDisplayName();
            } else if (currentUser.getEmail() != null) {
                usernameKey = currentUser.getEmail();
            } else {
                usernameKey = "Ismeretlen";
            }
            db.collection("user_tweets").document(usernameKey)
                    .collection("tweets")
                    .orderBy("timestamp", Query.Direction.DESCENDING)
                    .addSnapshotListener((QuerySnapshot snapshots, com.google.firebase.firestore.FirebaseFirestoreException error) -> {
                        if (error != null) {
                            Toast.makeText(UserProfileActivity.this, "Hiba a tweetek frissítésekor: " + error.getMessage(), Toast.LENGTH_LONG).show();
                            return;
                        }
                        if (snapshots != null) {
                            tweetList.clear();
                            for (DocumentSnapshot doc : snapshots.getDocuments()) {
                                if (!doc.contains("timestamp")) {
                                    Log.e("TweetError", "Tweet document missing timestamp: " + doc.getId());
                                    continue;
                                }
                                String tweetText = doc.getString("text");
                                String tweetUsername = doc.getString("username");
                                Long likeCount = doc.getLong("likeCount");
                                if (likeCount == null) {
                                    likeCount = 0L;
                                }
                                // Olvassuk ki a "bookmarkedBy" tömböt
                                java.util.List<String> bookmarkedBy = (java.util.List<String>) doc.get("bookmarkedBy");
                                if (bookmarkedBy == null) {
                                    bookmarkedBy = new ArrayList<>();
                                }
                                // Olvassuk ki az opcionális kép URL-t is
                                String imageUrl = doc.getString("imageUrl");
                                if (tweetText != null && tweetUsername != null) {
                                    tweetList.add(new Tweet(doc.getId(), tweetText, tweetUsername, likeCount, bookmarkedBy, imageUrl));
                                }
                            }
                            tweetAdapter.notifyDataSetChanged();
                        }
                    });
        }

        // Gomb: Kép választása
        buttonSelectImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Indítsd el a galéria megnyitását a kép kiválasztásához.
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_IMAGE_REQUEST);
            }
        });

        // Tweet mentése gomb
        buttonTweet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String tweet = editTextTweet.getText().toString().trim();
                if (tweet.isEmpty()) {
                    Toast.makeText(UserProfileActivity.this, "A tweet nem lehet üres.", Toast.LENGTH_SHORT).show();
                    return;
                }
                String usernameKey;
                if (currentUser != null && currentUser.getDisplayName() != null && !currentUser.getDisplayName().isEmpty()) {
                    usernameKey = currentUser.getDisplayName();
                } else if (currentUser != null && currentUser.getEmail() != null) {
                    usernameKey = currentUser.getEmail();
                } else {
                    usernameKey = "Ismeretlen";
                }
                // Ideiglenesen jelenítsük meg a tweetet a listában
                Tweet newTweet = new Tweet("", tweet, usernameKey, 0, new ArrayList<>(), "");
                tweetList.add(0, newTweet);
                tweetAdapter.notifyDataSetChanged();
                editTextTweet.setText("");
                imageViewPreview.setVisibility(View.GONE); // Tisztítsuk a kiválasztott képet
                selectedImageUri = null;

                // Készítsük el a tweetData map-et
                Map<String, Object> tweetData = new HashMap<>();
                tweetData.put("text", tweet);
                tweetData.put("timestamp", FieldValue.serverTimestamp());
                tweetData.put("username", usernameKey);
                tweetData.put("likedBy", new ArrayList<>()); // Kezdetben üres
                tweetData.put("likeCount", 0);
                tweetData.put("bookmarkedBy", new ArrayList<>());

                // Ha a tweethez tartozik kép, töltsük fel azt a Firebase Storage-ba
                if(selectedImageUri != null) {
                    StorageReference storageRef = FirebaseStorage.getInstance().getReference("tweet_images");
                    StorageReference imageRef = storageRef.child(System.currentTimeMillis() + ".jpg");
                    imageRef.putFile(selectedImageUri)
                            .addOnSuccessListener(taskSnapshot -> {
                                imageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                                    String imageUrl = uri.toString();
                                    tweetData.put("imageUrl", imageUrl);
                                    // Mentsük el a tweet-et, miután sikerült a kép feltöltése
                                    db.collection("user_tweets").document(usernameKey)
                                            .collection("tweets")
                                            .add(tweetData)
                                            .addOnSuccessListener(documentReference -> {
                                                Toast.makeText(UserProfileActivity.this, "Tweet elmentve!", Toast.LENGTH_SHORT).show();
                                            })
                                            .addOnFailureListener(e -> {
                                                Toast.makeText(UserProfileActivity.this, "Hiba a tweet mentésekor: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                            });
                                }).addOnFailureListener(e -> {
                                    Toast.makeText(UserProfileActivity.this, "Hiba a kép URL lekérésénél: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                });
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(UserProfileActivity.this, "Hiba a kép feltöltésekor: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            });
                } else {
                    // Ha nincs kép, akkor üres string vagy null érték kerül az imageUrl-hez
                    tweetData.put("imageUrl", "");
                    db.collection("user_tweets").document(usernameKey)
                            .collection("tweets")
                            .add(tweetData)
                            .addOnSuccessListener(documentReference -> {
                                Toast.makeText(UserProfileActivity.this, "Tweet elmentve!", Toast.LENGTH_SHORT).show();
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(UserProfileActivity.this, "Hiba a tweet mentésekor: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            });
                }
            }
        });
    }

    // Handle image selection result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            if(selectedImageUri != null) {
                // Mutassuk meg az előnézetet
                imageViewPreview.setVisibility(View.VISIBLE);
                imageViewPreview.setImageURI(selectedImageUri);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    public void Logout(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isLoggedIn", false);
        editor.apply();

        Intent intent = new Intent(UserProfileActivity.this, ProfileActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
