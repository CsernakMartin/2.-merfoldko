package com.example.projektmunka;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ListView listViewAllTweets;
    private ArrayList<Tweet> allTweetList;
    private TweetAdapter tweetAdapter;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Toolbar és navigációs drawer beállítása
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);

        LayoutInflater inflater = LayoutInflater.from(this);
        View customView = inflater.inflate(R.layout.toolbar_image, null);
        Toolbar.LayoutParams layoutParams = new Toolbar.LayoutParams(
                Toolbar.LayoutParams.WRAP_CONTENT,
                Toolbar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        toolbar.addView(customView, layoutParams);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        toggle.getDrawerArrowDrawable().setColor(Color.parseColor("#1da1f2"));
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.inflateMenu(R.menu.main_menu);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.nav_settings) {
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                }
                if (id == R.id.nav_profile) {
                    SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
                    boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);
                    if (isLoggedIn) {
                        startActivity(new Intent(MainActivity.this, UserProfileActivity.class));
                    } else {
                        startActivity(new Intent(MainActivity.this, ProfileActivity.class));
                    }
                }
                if (id == R.id.nav_bookmark) {
                    startActivity(new Intent(MainActivity.this, BookmarksActivity.class));
                }
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        // ListView inicializálása a tweetek megjelenítésére
        listViewAllTweets = findViewById(R.id.listViewAllTweets);
        allTweetList = new ArrayList<>();
        // A MainActivity-ben a törlés nem engedélyezett, ezért a "canDelete" flag false
        tweetAdapter = new TweetAdapter(this, allTweetList, false);
        listViewAllTweets.setAdapter(tweetAdapter);

        // Firestore inicializálása
        db = FirebaseFirestore.getInstance();

        // Minden tweet betöltése a Firestore "tweets" collectionGroup-ból,
        // rendezve a timestamp szerint csökkenő sorrendben
        db.collectionGroup("tweets")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((QuerySnapshot snapshots, FirebaseFirestoreException error) -> {
                    if (error != null) {
                        if (error.getCode() == FirebaseFirestoreException.Code.FAILED_PRECONDITION) {
                            Log.w("FirestoreQuery", "Non-critical error (FAILED_PRECONDITION): " + error.getMessage());
                        } else {
                            Toast.makeText(MainActivity.this,
                                    "Hiba a tweetek betöltésekor: " + error.getMessage(),
                                    Toast.LENGTH_LONG).show();
                            return;
                        }
                    }
                    if (snapshots != null) {
                        allTweetList.clear();
                        for (DocumentSnapshot doc : snapshots.getDocuments()) {
                            String tweetText = doc.getString("text");
                            String tweetUsername = doc.getString("username");
                            Long likeCount = doc.getLong("likeCount");
                            if (likeCount == null) {
                                likeCount = 0L;
                            }
                            // A "bookmarkedBy" tömb kiolvasása
                            java.util.List<String> bookmarkedBy = (java.util.List<String>) doc.get("bookmarkedBy");
                            if (bookmarkedBy == null) {
                                bookmarkedBy = new ArrayList<>();
                            }
                            if (tweetText != null && tweetUsername != null) {
                                // Feltételezzük, hogy a Tweet konstruktor 5 paramétert vár: id, text, username, likeCount, bookmarkedBy.
                                // Ha a kép URL nem része itt a dokumentumnak, azt egy üres stringként vagy null-ként adjuk át.
                                String imageUrl = doc.getString("imageUrl");
                                allTweetList.add(new Tweet(doc.getId(), tweetText, tweetUsername, likeCount, bookmarkedBy, imageUrl));
                            }
                        }
                        tweetAdapter.notifyDataSetChanged();
                    }
                });
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
