Légykedves és adj sok pontot légyszi
írj rám ha kell Csernák Martin-M7FDNM