package com.example.projektmunka;

import java.util.List;

public class Tweet {
    private String id;
    private String text;
    private String username;
    private long likeCount;
    private List<String> bookmarkedBy;
    private String imageUrl; // Új mező a feltöltött kép URL-jához

    public Tweet(String id, String text, String username, long likeCount, List<String> bookmarkedBy) {
        this(id, text, username, likeCount, bookmarkedBy, null);
    }

    // Új, teljes konstruktor
    public Tweet(String id, String text, String username, long likeCount, List<String> bookmarkedBy, String imageUrl) {
        this.id = id;
        this.text = text;
        this.username = username;
        this.likeCount = likeCount;
        this.bookmarkedBy = bookmarkedBy;
        this.imageUrl = imageUrl;
    }

    // Getterek és setterek...
    public String getId() { return id; }
    public String getText() { return text; }
    public String getUsername() { return username; }
    public long getLikeCount() { return likeCount; }
    public void setLikeCount(long likeCount) { this.likeCount = likeCount; }
    public List<String> getBookmarkedBy() { return bookmarkedBy; }
    public void setBookmarkedBy(List<String> bookmarkedBy) { this.bookmarkedBy = bookmarkedBy; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
}
